﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Globalization;
using analog_clock;


namespace AnalogClock
{
    public partial class Form1 : Form
    {
        Timer timer1 = new Timer();
        Bitmap bitmap1;
        Graphics graphics1;
        int xcenter, ycenter; //center of the clock
        int secondhand = 140, minutehand = 110, hourhand = 80, WIDTH = 300, HEIGHT = 300;

        public Form1()
        {
            DoubleBuffered = true;
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.DoubleBuffered = true;

            //creation of bitmap that will be used for graphics
            bitmap1 = new Bitmap(WIDTH + 1, HEIGHT + 1);

            //x and y coordinate for the center of the clock 
            xcenter = WIDTH / 2;
            ycenter = HEIGHT / 2;

            //backgroundcolor
            this.BackColor = Color.White;

            //timer of the clock
            timer1.Interval = 1000; //represented by miliseconds
            timer1.Tick += new EventHandler(this.Timer_Tick);
            timer1.Start();
        }

        private void Timer_Tick(Object sender, EventArgs e)
        {
            //graphics creation
            graphics1 = Graphics.FromImage(bitmap1);

            //retrieves the time of the current machine
            int seconds = DateTime.Now.Second;
            int minutes = DateTime.Now.Minute;
            int hours = DateTime.Now.Hour;


           
            if (comboBox1.SelectedItem == "Budapest(UTC+1:00)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute;
                hours = DateTime.Now.Hour - 10;
            }
           

            if (comboBox1.SelectedItem == "Athens(UTC+2:00)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute;
                hours = DateTime.Now.Hour - 9;
            }

            if (comboBox1.SelectedItem == "Kuwait(UTC+3:00)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute;
                hours = DateTime.Now.Hour - 9;
            }

            if (comboBox1.SelectedItem == "Tehran(UTC+3:30)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute - 30;
                hours = DateTime.Now.Hour - 7;
            }

            if (comboBox1.SelectedItem == "Abu Dhabi(UTC+4:00)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute - 30;
                hours = DateTime.Now.Hour - 8;
            }

            if (comboBox1.SelectedItem == "Kabul(UTC+4:30)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute - 30;
                hours = DateTime.Now.Hour - 7;
            }

            if (comboBox1.SelectedItem == "Islamabad(UTC+5:00)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute;
                hours = DateTime.Now.Hour - 7;
            }

            if (comboBox1.SelectedItem == "New Delhi (UTC+5:30)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute - 30;
                hours = DateTime.Now.Hour - 6;
            }

            if (comboBox1.SelectedItem == "Kathmandu(UTC+5:45)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute - 15;
                hours = DateTime.Now.Hour - 6;
            }

            if (comboBox1.SelectedItem == "Dhaka(UTC+6:00)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute;
                hours = DateTime.Now.Hour - 6;
            }


            if (comboBox1.SelectedItem == "Yangon(UTC+6:30)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute - 30;
                hours = DateTime.Now.Hour - 5;
            }

            if (comboBox1.SelectedItem == "Bangkok(UTC+7:00)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute;
                hours = DateTime.Now.Hour - 5;
            }

            if (comboBox1.SelectedItem == "Beijing(UTC+8:00)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute;
                hours = DateTime.Now.Hour - 4;
            }

            if (comboBox1.SelectedItem == "Osaka(UTC+9:00)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute;
                hours = DateTime.Now.Hour - 3;
            }

            if (comboBox1.SelectedItem == "Adelaide(UTC+9:30)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute - 30;
                hours = DateTime.Now.Hour - 2;
            }

            if (comboBox1.SelectedItem == "Sydney(UTC+10:00))")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute;
                hours = DateTime.Now.Hour - 2;
            }

            if (comboBox1.SelectedItem == "Solomon Island(UTC+11)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute;
                hours = DateTime.Now.Hour - 1;
            }

            if (comboBox1.SelectedItem == "Auckland(UTC+12:00)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute;
                hours = DateTime.Now.Hour;
            }

            if (comboBox1.SelectedItem == "Azores(UTC-1:00)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute;
                hours = DateTime.Now.Hour - 12;
            }

            if (comboBox1.SelectedItem == "Auckland(UTC+12:00)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute;
                hours = DateTime.Now.Hour;
            }

            if (comboBox1.SelectedItem == "Coordinated universal time(UTC-2:00)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute;
                hours = DateTime.Now.Hour - 14;
            }

            if (comboBox1.SelectedItem == "Greenland(UTC-3:00)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute;
                hours = DateTime.Now.Hour - 14;
            }

            if (comboBox1.SelectedItem == "Newfoundland(UTC-3:30)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute - 30;
                hours = DateTime.Now.Hour - 14;
            }

            if (comboBox1.SelectedItem == "Indiana(UTC-5:00)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute;
                hours = DateTime.Now.Hour - 16;
            }

            if (comboBox1.SelectedItem == "Saskatchewan(UTC-6:00)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute;
                hours = DateTime.Now.Hour - 18;
            }

            if (comboBox1.SelectedItem == "Arizona(UTC-7:00)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute;
                hours = DateTime.Now.Hour - 19;
            }

            if (comboBox1.SelectedItem == "Pacific Time(UTC-8:00)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute;
                hours = DateTime.Now.Hour - 20;
            }

            if (comboBox1.SelectedItem == "Alaska(UTC-9:00)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute;
                hours = DateTime.Now.Hour - 21;
            }

            if (comboBox1.SelectedItem == "Hawaii(UTC-10:00)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute;
                hours = DateTime.Now.Hour - 22;
            }

            if (comboBox1.SelectedItem == "Coordinated universal time 11(UTC-11:00)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute;
                hours = DateTime.Now.Hour - 23;
            }

            if (comboBox1.SelectedItem == "Coordinated universal time 11(UTC-11:00)")
            {
                seconds = DateTime.Now.Second;
                minutes = DateTime.Now.Minute;
                hours = DateTime.Now.Hour - 24;
            }


            int[] handscoordinate = new int[2];


            //clear
            graphics1.Clear(Color.White);

            //draw circle of the clock
            graphics1.DrawEllipse(new Pen(Color.Black, 1f), 0, 0, WIDTH, HEIGHT);

            //draw numbers

            graphics1.DrawString("1", new Font("Arial", 12), Brushes.Black, new PointF(215, 20));
            graphics1.DrawString("2", new Font("Arial", 12), Brushes.Black, new PointF(265, 70));
            graphics1.DrawString("3", new Font("Arial", 12), Brushes.Black, new PointF(286, 140));
            graphics1.DrawString("4", new Font("Arial", 12), Brushes.Black, new PointF(270, 210));
            graphics1.DrawString("5", new Font("Arial", 12), Brushes.Black, new PointF(215, 265));
            graphics1.DrawString("6", new Font("Arial", 12), Brushes.Black, new PointF(142, 282));
            graphics1.DrawString("7", new Font("Arial", 12), Brushes.Black, new PointF(70, 265));
            graphics1.DrawString("8", new Font("Arial", 12), Brushes.Black, new PointF(20, 210));
            graphics1.DrawString("9", new Font("Arial", 12), Brushes.Black, new PointF(0, 140));
            graphics1.DrawString("10", new Font("Arial", 12), Brushes.Black, new PointF(20, 70));
            graphics1.DrawString("11", new Font("Arial", 12), Brushes.Black, new PointF(70, 20));
            graphics1.DrawString("12", new Font("Arial", 12), Brushes.Black, new PointF(140, 2));


            //hourhand coordinate
            handscoordinate = hourcoordinate(hours % 12, minutes, hourhand);
            graphics1.DrawLine(new Pen(Color.Gray, 3f), new Point(xcenter, ycenter), new Point(handscoordinate[0], handscoordinate[1]));

            //minuteshand coordinate
            handscoordinate = minutesandsecondcoordinate(minutes, minutehand);
            graphics1.DrawLine(new Pen(Color.Black, 2f), new Point(xcenter, ycenter), new Point(handscoordinate[0], handscoordinate[1]));

            //secondhand coordinate
            handscoordinate = minutesandsecondcoordinate(seconds, secondhand);
            graphics1.DrawLine(new Pen(Color.Red, 1f), new Point(xcenter, ycenter), new Point(handscoordinate[0], handscoordinate[1]));

            //load bitmap in the picture box
            pictureBox1.Image = bitmap1;

            //display time on form1
            this.Text = "Analog Clock - " + hours + ":" + minutes + ":" + seconds;

            graphics1.Dispose();

 
        }

        //method for clock minutes and seconds coordinate
        private int[] minutesandsecondcoordinate(int value, int hlen)
        {
            int[] coordinate = new int[2];
            value *= 6; //minutes and seconds moves by 6 degrees

            if (value >= 0 && value <= 180)
            {
                coordinate[0] = xcenter + (int)(hlen * Math.Sin(Math.PI * value / 180));
                coordinate[1] = ycenter - (int)(hlen * Math.Cos(Math.PI * value / 180));
            }

            else
            {
                coordinate[0] = xcenter - (int)(hlen * -Math.Sin(Math.PI * value / 180));
                coordinate[1] = ycenter - (int)(hlen * Math.Cos(Math.PI * value / 180));
            }
            return coordinate;
        }

        //method for clock hour hand coordinate    
        private int[] hourcoordinate(int hourvalue, int minutevalue, int hlen)
        {
            int[] coordinate = new int[2];

            int value = (int)((hourvalue * 30) + (minutevalue * 0.5));

            if (value >= 0 && value <= 180)
            {
                coordinate[0] = ycenter + (int)(hlen * Math.Sin(Math.PI * value / 180));
                coordinate[1] = xcenter - (int)(hlen * Math.Cos(Math.PI * value / 180));
            }

            else
            {
                coordinate[0] = xcenter - (int)(hlen * -Math.Sin(Math.PI * value / 180));
                coordinate[1] = ycenter - (int)(hlen * Math.Cos(Math.PI * value / 180));
            }
            return coordinate;


        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
 
        }

        private void button1_Click(object sender, EventArgs e)
        {

            label2.Text = comboBox1.SelectedItem.ToString();
        }
            /*
            try
            {
                if (comboBox1.SelectedItem == "Budapest(UTC+1:00)")
                {
                    int seconds = DateTime.UtcNow.Second;
                    int minutes = DateTime.UtcNow.Minute;
                    int hours = DateTime.Now.Hour + 5;
                }
            }
            catch(Exception)
            {
                MessageBox.Show("okay");
            }

        }
            */
        private void button2_Click(object sender, EventArgs e)
        {
            label2.Text = "";

        }
    }
}
