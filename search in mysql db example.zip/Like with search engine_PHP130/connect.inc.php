

<?php 


$mysqlhost = 'localhost'; 
$mysqluser = 'root'; 
$mysqlpass = '';
$mysqldbname = 'a_database';

@$mysqlcon= mysqli_connect($mysqlhost,$mysqluser,$mysqlpass) or die('could not connect.'); 
MySQLi_select_db($mysqlcon , $mysqldbname) or die('no such db'); 



 
 ?> 



