Hi Doug,

It seems like that Waiariki network is blocking the application to connect to imdb and retrieve information,
This application works smoothly other network except waiariki network. 

Please change the connection string of the database located in form1 to use the save and update button.

Kind regards,

Ian Montero