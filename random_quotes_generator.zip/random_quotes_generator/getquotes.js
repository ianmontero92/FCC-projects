var getQuote = function() {
  $.ajax({
    url: 'http://api.icndb.com/jokes/random', //with values of: { "type": "success", "value": { "id": 259, "joke": "When Chuck Norris does division, there are no remainders.", "categories": [] } }
    type: 'GET',
    contentType: 'application/json',
    dataType: 'jsonp',
    success: function(data) {
      $('.quote').html((data['value']['joke']));
      var tweethref = 'https://twitter.com/intent/tweet?text=' + (data['value']['joke']);
      $('.twitter-share-button').attr('href', tweethref);

    }
  });
}

$(document).ready(function() {
  // get a random quote when page loads
  getQuote();
  $('.quote-btn').click(getQuote);

});